"""Prepare the metadata-selected exit/funding-memory grid and exact original settlement guards."""
from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json
ROOT=Path.cwd();R=ROOT/'research/experiments/20261125T094408Z';P=ROOT/'research/experiments/20261125T074237Z';F=ROOT/'.git/automation_proofs'
rd=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();put=lambda p,x:p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');rel=lambda p:str(p.relative_to(ROOT));now=lambda:datetime.now(timezone.utc).isoformat()
m=rd(R/'joint_parameter_metadata_availability.json')['selected'];assert m['axis']=='exit_buffer_fraction' and m['values']==[.00375,.005,.00625] and m['new_graphs']==4 and m['representative_preset']=={'W':.00375,'K':7};assert not (R/'plan.json').exists()
texts={p.name:p.read_text() for p in R.glob('*.py')};changes=[]
def rep(name,old,new,count=None):
 n=texts[name].count(old);assert n and (count is None or n==count),(name,old,n,count);texts[name]=texts[name].replace(old,new);changes.append({'source':name,'old':old,'new':new,'matches':n})
axis='BTC_EXIT_BUFFER_FRACTION';oldaxis='BTC_ENTRY_VOLATILITY_WINDOW_DAYS'
for n in ['freeze_confirmation.py','run.py','audit.py','sizing_units.py','exports.py']:
 rep(n,oldaxis,axis)
rep('prepare.py','PID==1556142','PID==1583301',1)
rep('prepare.py',"known16=rd(ROOT/h['actual_Nov23_16_source']);first16ms=min(int(z['fundingTime']) for xs in known16['public_fields_by_asset'].values() for z in xs);lo=datetime.fromtimestamp(min(ms(lo),first16ms-1)/1000,timezone.utc).isoformat().replace('+00:00','Z')","earliest_doc=rd(ROOT/h['actual_Nov23_08_source']);first_ms=min(int(z['fundingTime']) for xs in earliest_doc['public_fields_by_asset'].values() for z in xs);lo=datetime.fromtimestamp(min(ms(lo),first_ms-1)/1000,timezone.utc).isoformat().replace('+00:00','Z')",1)
rep('prepare.py','including exact known16 source context','including all five first actual settlement sources',1)
rep('prepare.py',"{'SMA':0,'candidate':0,'l4h02':0,'fewm':0}","{'SMA':0,'candidate':0,'l4h02':6,'fewm':6}",1)
rep('prepare.py','CurrentSMA/candidateNov24_10:30..12:30 andL4/FEWMNov24_12:10..14:10 marks only. All3 own actual08 keys already6 each, no repeat;all4 daily0/fills0/newfunding0.','Current SMA/candidate Nov24_12:30..14:30 closed marks only; L4/FEWM Nov24_14:10..16:10 closed marks plus actual16 funding. All3 own old08 keys already6 each, no repeat; all4 daily0/fills0, new funding counts SMA0/candidate0/L4six/FEWMsix.',1)
rep('prepare.py',"'reference':'turn425view0'","'reference':'turn426view0'",1)
newguard="""
# Exact genuinely first Nov24_16 response, original UTC and each own unbooked key, before ANY reserve.
entrylast=next(e for e in h['next_window_known_actual_funding_sources'] if e['sha256']=='b83d66f870d189d066c4939190c39b16a44e3785ef23277e70d85250a7e8cf5d');originlast=ROOT/entrylast['path'];locallast=R/originlast.name;doclast=rd(locallast)
assert sha(originlast)==sha(locallast)==entrylast['sha256'] and doclast['recorded_utc']==entrylast['original_capture_utc']=='2026-11-25T08:05:57.950668Z' and doclast['public_fields_by_asset']==entrylast['actual_public_fields']
timeslast={str(int(z['fundingTime'])*1000000) for xs in doclast['public_fields_by_asset'].values() for z in xs};assert timeslast=={'1795536000000000000'}
for asset in ['BTC','ETH']:
 ids={int(z['fundingTime']) for z in doclast['public_fields_by_asset'][asset]};assert [z for z in response[asset] if int(z['fundingTime']) in ids]==doclast['public_fields_by_asset'][asset]
for item in doclast['HTTP_receipts']:
 assert sha(ROOT/item['raw'])==item['sha256'];sources[item['raw']]=item['sha256']
 if item['http_status']==200 and not item['curl_exit_code']:
  rows=gz(ROOT/item['raw'])
  for asset,fields in doclast['public_fields_by_asset'].items():
   if 'symbol='+asset+'USDT' in item['url']:assert all(z in rows for z in fields)
pclast={a:{t:prior08[a]['funding'].get(t,0) for t in timeslast} for a in ['candidate','l4h02','fewm']};assert pclast==entrylast['current_own_booked_counts'] and all(sum(z.values())==0 for z in pclast.values())
inclast={a:{t:sum(3 for xs in windows[a]['expected_funding_by_asset'].values() for z in xs if str(int(z['fundingTime'])*1000000)==t) for t in timeslast} for a in pclast};assert {a:sum(xs.values()) for a,xs in inclast.items()}=={'candidate':0,'l4h02':6,'fewm':6}
prooflast=R/'actual16_nov24_prebinding_source.json';put(prooflast,{'passed':True,'recorded_utc':now(),'source':rel(locallast),'sha256':sha(locallast),'original_source':rel(originlast),'first_capture_utc':doclast['recorded_utc'],'actual_public_fields':doclast['public_fields_by_asset'],'prior_unique_counts':pclast,'expected_current_increment_counts':inclast,'fresh_exact_source_fields_equal':True,'original_successful_HTTP_raw_bytes_verified':True,'before_any_current_reservation':True,'cashflow_calculations':0,'own_signed_q_and_cost_required_no_cashflow_copy':True});sources.update({rel(prooflast):sha(prooflast),rel(originlast):sha(originlast)})
"""
rep('prepare.py',"put(R/'original_accounts_binding.json'",newguard+"\nput(R/'original_accounts_binding.json'",1)
rep('freeze_confirmation.py','WS=[9,10,11]','WS=[.00375,.005,.00625]',1)
rep('freeze_confirmation.py',"'BTC_entry_volatility_window_days':w","'BTC_exit_buffer_fraction':w")
rep('freeze_confirmation.py','[9,11]','[.00375,.00625]')
rep('freeze_confirmation.py','parents[10,k]','parents[.005,k]')
rep('freeze_confirmation.py','parent_BTCVolV','parent_BTCExitE',1)
rep('freeze_confirmation.py','btc-entry-volatility-window-eth-funding-budget-volwindow-passive-combination','btc-exit-buffer-eth-funding-budget-volwindow-passive-combination',1)
rep('freeze_confirmation.py','BTC completed sample logvol estimation window 9/10/11 days; cap.0275, L29/H.03/E.005, ROC5 confirmation .0025 and N1000 fixed; entry gate only.','BTC position-exit hysteresis buffer E=.00375/.005/.00625 (fraction,0.375/0.5/0.625 percent); V10cap.0275,L29,H.03,ROC5 .0025,N1000 fixed. Long held while completed29dROC>-E and short while ROC<E, unless a new opposite entry signal.',1)
rep('freeze_confirmation.py',"g['W']==9 and g['K']==7","g['W']==.00375 and g['K']==7",1)
rep('freeze_confirmation.py',"{'W':9,'K':7}","{'W':.00375,'K':7}",1)
for n in ['freeze_confirmation.py','review_joint_economics.py']:
 rep(n,'additional_predeclared_BTCVolV10_report_controls','additional_predeclared_BTCExitE0p005_report_controls')
rep('run.py',"'BTC_exit_buffer_fraction_fixed':0.005","'BTC_exit_buffer_fraction':[.00375,.005,.00625]",1)
rep('run.py',"'BTC_entry_volatility_window_days':[9,10,11]","'BTC_entry_volatility_window_days_fixed':10",1)
rep('definitions.py',"{'W':9,'K':7}","{'W':.00375,'K':7}",1)
rep('definitions.py',"q['BTC_entry_volatility_window_days']==row['W'] in [9,11]","q['BTC_exit_buffer_fraction']==row['W'] in [.00375,.00625]",1)
rep('definitions.py',"q['BTC_exit_buffer_fraction']==.005","q['BTC_entry_volatility_window_days']==10",1)
rep('definitions.py',"'actual08_nov24_prebinding_source.json','parent_primitive_verification.json'","'actual08_nov24_prebinding_source.json','actual16_nov24_prebinding_source.json','parent_primitive_verification.json'",1)
rep('boundary_units.py',"{'SMA':0,'candidate':0,'l4h02':0,'fewm':0}","{'SMA':0,'candidate':0,'l4h02':6,'fewm':6}",1)
insert="""
last=rd(R/'actual16_nov24_prebinding_source.json');assert last['passed'] and last['before_any_current_reservation'] and sha(ROOT/last['source'])==last['sha256']=='b83d66f870d189d066c4939190c39b16a44e3785ef23277e70d85250a7e8cf5d' and last['first_capture_utc']=='2026-11-25T08:05:57.950668Z' and {a:sum(z.values()) for a,z in last['prior_unique_counts'].items()}=={'candidate':0,'l4h02':0,'fewm':0} and {a:sum(z.values()) for a,z in last['expected_current_increment_counts'].items()}=={'candidate':0,'l4h02':6,'fewm':6}
assert {str(int(z['fundingTime'])*1000000) for xs in last['actual_public_fields'].values() for z in xs}=={'1795536000000000000'}
"""
rep('boundary_units.py',"full=rd(R/'SMA_full76_prebinding.json')",insert+"\nfull=rd(R/'SMA_full76_prebinding.json')",1)
rep('boundary_units.py','all4 daily0/allfunding0/original source keys6each','all4 daily0/SMA-C funding0/L4-FEWM funding6each/old source keys6each/new16keys0 before reserve',1)
rep('boundary_units.py',"'exact_actual00_source_SHA_originalUTC_retained':True","'exact_actual00_source_SHA_originalUTC_retained':True,'new16_source_SHA_originalUTC_fields_and_own_unbooked_keys_bound':True",1)
rep('sizing_units.py',"[9,10,11]","[.00375,.005,.00625]",1)
rep('sizing_units.py',"b['entry_volatility_window_days']==g['W']","b['exit_buffer_fraction']==g['W']",1)
rep('sizing_units.py',"b['exit_buffer_fraction']==.005","b['entry_volatility_window_days']==10",1)
rep('sizing_units.py',"(b,baseBTC,'entry_volatility_window_days',10,g['W'])","(b,baseBTC,'exit_buffer_fraction',.005,g['W'])",1)
rep('exports.py',"BTC_entry_volatility_window_days=c['W']","BTC_exit_buffer_fraction=c['W']",1)
rep('exports.py','BTC entry volatility estimation window (days)','BTC exit hysteresis buffer (fraction)',1)
rep('exports.py','BTC entry volatility estimation window x ETH funding-budget volatility window','BTC exit hysteresis buffer x ETH funding-budget volatility window',1)
rep('exports.py','BTC V9/10/11 days; cap .0275, H .03, E .005, L29, ROC5 .0025, N1000 fixed','BTC E .00375/.005/.00625; V10 cap .0275, H .03, L29, ROC5 .0025, N1000 fixed',1)
rep('review_joint_economics.py','same-ETH-budget-volatility-window BTC V10 controls','same-ETH-budget-volatility-window BTC E.005 controls',1)
rep('review_joint_economics.py',"'BTC_entry_volatility_window_days':c['W']","'BTC_exit_buffer_fraction':c['W']",1)
rep('review_joint_economics.py','matched_ETHbudgetVW_BTC_V10_comparisons','matched_ETHbudgetVW_BTC_E0p005_comparisons',1)
rep('review_joint_economics.py','central_V10_VW9_comparisons','central_E0p005_VW9_comparisons',1)
rep('saved_review.py',"{'W':9,'K':7}","{'W':.00375,'K':7}",1)
rep('saved_review.py',"c['W']==9 and c['K']==7","c['W']==.00375 and c['K']==7",1)
rep('saved_review.py','BTC入场估计窗V9/ETH预算VW7','BTC退出缓冲E.00375/ETH预算VW7',1)
rep('saved_review.py','BTC V10对照','BTC E.005对照',1)
# Reconcile the genuinely covered new16 cashflows only after each original window has executed.
rep('collect.py',"('Nov24_08','actual08_nov24_prebinding_source.json')]};new=firsts['Nov24_08']","('Nov24_08','actual08_nov24_prebinding_source.json'),('Nov24_16','actual16_nov24_prebinding_source.json')]};new=firsts['Nov24_16']",1)
rep('collect.py',"counts=={'SMA':0,'candidate':0,'l4h02':0,'fewm':0}","counts=={'SMA':0,'candidate':0,'l4h02':6,'fewm':6}",1)
rep('collect.py',"assert daily['1795478460000000000']==6","assert daily['1795478460000000000']==6 and fund['1795536000000000000']=={'candidate':0,'l4h02':6,'fewm':6}[a]",1)
rep('collect.py',"'first_actual08_sha256':new['sha256'],'first_actual08_capture_utc':new['first_capture_utc']","'first_actual08_sha256':firsts['Nov24_08']['sha256'],'first_actual08_capture_utc':firsts['Nov24_08']['first_capture_utc'],'first_actual16_sha256':new['sha256'],'first_actual16_capture_utc':new['first_capture_utc'],'current_actual16_unique_counts':{a:fullcounts[a]['funding'].get('1795536000000000000',0) for a in ['candidate','l4h02','fewm']},'own_actual16_cashflows':flows",1)
rep('collect.py','single_actualNov24_08_not_yet_booked=False,next_new_actual_funding_pending_by_own_window','single_actualNov24_08_not_yet_booked=False,L4_FEWM_actualNov24_16_booked_once=True,single_actualNov24_16_not_yet_booked=True,all3_perp_actualNov24_16_booked_once=False,next_new_actual_funding_pending_by_own_window',1)
rep('collect.py','All3 original perps now have six unique Nov24_08 keys;do not repeat.','All3 original perps have six unique old Nov24_08 keys;do not repeat. For actualNov24_16 candidate still has0 while L4 andFEWM now have6 own keys each;only candidate next window covers this event. Retain first SHA b83d66f870d189d066c4939190c39b16a44e3785ef23277e70d85250a7e8cf5d/originalUTC2026-11-25T08:05:57.950668Z/exact fields;do not repeat L4/FEWM.',1)
rep('collect.py','Current all4 daily0/fills0/newfunding0;each original account appends only closed marks.','Current all4 daily0/fills0;SMA/candidate append closed marks and funding0,L4/FEWM book six own actual16 records each plus closed marks.',1)
rep('collect.py','本轮BTC入场logvol估计窗V9/11×ETH资金费预算VW7/12四个新角点已完成','本轮BTC退出缓冲E.00375/.00625×ETH资金费预算VW7/12四个新角点已完成',1)
rep('collect.py','# BTC/ETH 双估计窗口研究','# BTC退出缓冲与ETH资金费预算记忆研究',1)
rep('collect.py','|BTC入场logvol估计窗（日）|','|BTC退出缓冲（比例）|',1)
rep('collect.py','代表BTC V9/ETH预算VW7','代表BTC E.00375/ETH预算VW7',1)
rep('collect.py','BTC V10旧对照','BTC E.005旧对照')
rep('collect.py','中心BTC V10/ETH预算VW9','中心BTC E.005/ETH预算VW9',1)
rep('collect.py','BTC波动率拦截与desired/交易差分','BTC退出缓冲与desired/交易差分',1)
rep('collect.py',"实际Nov24_08首次源SHA{new['sha256']}","实际Nov24_16首次源SHA{new['sha256']}",1)
rep('collect.py','三原永续账户此前已各自按原signedq和真实rate/mark核算该事件，每个账户六唯一键；本轮全部窗口不再覆盖该事件，不得重复。四账户只追加已闭合mark，原现金、数量、desired及成本保持；资金费收入不放大、支出按1/2/3倍。','本轮只有L4与FEWM各自窗口覆盖该事件，分别按各自原signedq及真实rate/mark入账各六唯一键；candidate窗口尚未覆盖仍为零。ETH数量为零仍保留真实零金额资金费行，不虚构持仓。所有账户无新日决策/成交，原数量、desired和执行成本保持；L4/FEWM现金仅增加各自真实资金费，收入不放大、支出按1/2/3倍。旧Nov24_08均已记六键不得重复。',1)
# Explicitly audit partial per-account progress on the new16 source and preserve its original first receipt.
extra="""
last=rd(R/'actual16_nov24_prebinding_source.json');assert last['sha256']=='b83d66f870d189d066c4939190c39b16a44e3785ef23277e70d85250a7e8cf5d' and last['first_capture_utc']=='2026-11-25T08:05:57.950668Z' and {a:sum(z.values()) for a,z in last['prior_unique_counts'].items()}=={'candidate':0,'l4h02':0,'fewm':0} and {a:sum(z.values()) for a,z in last['expected_current_increment_counts'].items()}=={'candidate':0,'l4h02':6,'fewm':6}
assert {a:aw['full_chain_once_counts'][a]['funding'].get('1795536000000000000',0) for a in ['candidate','l4h02','fewm']}=={'candidate':0,'l4h02':6,'fewm':6} and h['actual_Nov24_16_counts_by_account']=={a:{'1795536000000000000':n} for a,n in [('candidate',0),('l4h02',6),('fewm',6)]}
assert h['L4_FEWM_actualNov24_16_booked_once'] and h['single_actualNov24_16_not_yet_booked'] and not h['all3_perp_actualNov24_16_booked_once']
"""
rep('verify_next_funding_handoff.py',"ms=lambda s:int(datetime.fromisoformat",extra+"\nms=lambda s:int(datetime.fromisoformat",1)
rep('verify_next_funding_handoff.py',"'actual08_own_counts':h['actual_Nov24_08_counts_by_account']","'actual08_own_counts':h['actual_Nov24_08_counts_by_account'],'actual16_own_counts':h['actual_Nov24_16_counts_by_account'],'actual16_first_source_SHA':last['sha256'],'actual16_original_capture_UTC':last['first_capture_utc']",1)
rep('verify_next_funding_handoff.py',"'all3_original_perps_actual16_and08_unique_counts6_each':True","'all3_original_perps_actual16_and08_unique_counts6_each':True,'legacy_count_scope':'Nov23_16 and Nov24_08;new Nov24_16 is explicitly per-account','newNov24_16_counts':h['actual_Nov24_16_counts_by_account']",1)
# Validate all source text before mutating this prepared, still-unreserved round.
for n,t in texts.items():ast.parse(t)
core=['engine.py','core391_tail_safe.py','market.py','portfolio.py','audit_native.py','observe_l4h02.py','observe_fewm.py','audit_incremental.py','forward.py']
assert all(texts[n]==(P/n).read_text() for n in core)
for n,t in texts.items():(R/n).write_text(t)
design=rd(P/'research_design.json');design.update(round=R.name,frozen_utc=now(),hypothesis='固定BTC L29/H.03、入场样本logvol V10及cap.0275、ROC5严格方向门槛.0025、C3750/N1000，只改变持仓退出滞回缓冲E=.00375/.005旧/.00625（比例，0.375%/0.5%/0.625%）：已有多头29日已完成ROC>-E继续持有，已有空头ROC<E继续持有，新的反向入场信号优先。联合ETH资金费预算已完成日logvol估计窗VW=7/9旧/12天；R.0075、M4、年龄1..36h/保守1h可得延迟、longonly、有限EWMS16 D3/K.0075、L5/H.02/E.0075、入场V6cap.05625、C15000/N4000保持。检验退出滞回宽度与入场资金费预算记忆的联合影响。全图按定义先查重：四新角点BTC E.00375/.00625×ETH预算VW7/12，五旧格只读；代表E.00375/VW7结果前固定，不择优改选。原始完整银行乘数[1,1]，总资本18750、资金占比20%/80%、初始目标总敞口5000，不归一化、数量缩放、划拨、再平衡或交叉保证金。',axes={axis:[.00375,.005,.00625],'ETH_FUNDING_BUDGET_VOLATILITY_WINDOW_DAYS':[7,9,12]},representative_preset={'W':.00375,'K':7});put(R/'research_design.json',design)
put(R/'registry_archive_plan.json',{'recorded_utc':now(),'planned_before_any_reservation':True,'own_finished_IDs':16,'own_raw_reserve_finish_events':32,'preserve_original_event_bytes':True,'main_registry_restore_exact_starting_bytes':True,'all_fragments_and_logical_multiset_preserved':True})
helpers=['review_joint_economics.py','saved_review.py','collect.py','exports.py','retain_transport_failures.py','verify_next_funding_handoff.py'];put(R/'readonly_formatter_binding.json',{'recorded_utc':now(),'before_any_current_reservation':True,'helpers':{rel(R/n):sha(R/n) for n in helpers},'new_strategy_or_account_evaluations':0})
for file,script in [('next_funding_checker_binding.json','verify_next_funding_handoff.py'),('transport_failure_binding.json','retain_transport_failures.py'),('saved_review_binding.json','saved_review.py')]:put(R/file,{'recorded_utc':now(),'source':rel(R/script),'source_sha256':sha(R/script),'bound_before_execution':True,'new_strategy_or_account_evaluations':0})
put(R/'pre_reserve_source_adaptation.json',{'recorded_utc':now(),'metadata_selected_axis':m['axis'],'BTC_values':m['values'],'ETH_values':m['ETH_values'],'nine_unchanged_monetary_sources':{n:sha(R/n) for n in core},'source_changes':changes,'new_model_account_or_cashflow_evaluations':0,'all_before_any_current_reservation':True,'exact_new16_first_source_to_be_refreshed_and_bound_before_reserve':{'sha256':'b83d66f870d189d066c4939190c39b16a44e3785ef23277e70d85250a7e8cf5d','original_capture_utc':'2026-11-25T08:05:57.950668Z','prior_own_counts':{'candidate':0,'l4h02':0,'fewm':0},'expected_current_counts':{'candidate':0,'l4h02':6,'fewm':6}}})
p=F/(R.name+'_publish.py');t=p.read_text().replace('research: validate BTC and ETH volatility-memory windows','research: validate BTC exit buffer and ETH funding-memory combinations');ast.parse(t);p.write_text(t)
p=F/(R.name+'.json');d=rd(p);d['native_complete_history_and_metadata']={'initial_chunk_id':'1d79b9','session_id':31279,'completion_chunk_id':'60688e','exit_code':0,'full_events':42646,'full_IDs':21184,'all_conclusions':543,'full_extra_reads':29,'protected_files':118392};d['status']='predeclared_exit_buffer_grid_and_original_actual16_guards_prepared';put(p,d)
print(json.dumps({'prepared_sources':True,'axis':axis,'new_financial_or_account_calculations':0,'nine_monetary_sources_identical':True,'source_adaptations':len(changes)},ensure_ascii=False))
